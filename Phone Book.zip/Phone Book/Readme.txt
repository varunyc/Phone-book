Prerequisites:
1. Install Django from https://docs.djangoproject.com/en/3.2/topics/install/
2. Install Python 3.7.6 from https://www.python.org/downloads/release/python-376/
3. Install Visual studio code from https://code.visualstudio.com/download



Steps to Run:
1. Unzip the code after downloading it from GitHub
2. Go to the directory where manage.py is present
3. python ./manage.py runserver
4. Open the link which is shown after running command in step -3
