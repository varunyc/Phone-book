from django.contrib import admin
from .models import address,book
# Register your models here.
admin.site.register(address)
admin.site.register(book)
